# RSI-Flow 原生 Skill 注册与调度

在第四周已有的“匹配经验”环节接入两个 Java 节点。浏览器点击“运行 10 题”后，每题的公开样例和反例观测都进入 RSI-Flow 的 Spring 流程入口。引擎依次执行诊断、分流，把结果交回原编排决定是否进入修订。冻结十题取得 **10 个不同的引擎调用号**，其中 4 题诊断为数值比较差异、3 题为公开样例不匹配、3 题为构造反例命中。另取保留题 `abc382_g`，同一流程返回“需要反例”，走转人工分支。

![浏览器运行与原生调用号](../evidence/native-platform.png)

| 教学步骤 | 本次实现 | 如何核实 |
|---|---|---|
| 注册节点 | 用 `@FlowComponent` 和 `@Flow` 登记 `WEEK4_DIAGNOSE`、`WEEK4_ROUTE` 两个方法。 | [Java 节点](src/week4/nativeflow/Week4Skills.java) |
| 装配流程 | 流程标识为 `@week4.evoagentbench/FAILURE_DIAGNOSIS`。第二个节点读取第一个节点注册的 `diagnosis`，并写回 `result`。 | [流程定义](resources/flow/week4/flow-failure-diagnosis.json) · [运行时注册表查询](src/week4/nativeflow/Registration.java) |
| 调度与取回 | 用原后端 `FlowEngineController` 和 `FlowEngineService` 接收 `POST /api/engine/flow`，由服务执行参数注册、`FlowEngine.run(flowId)`、结果提取和释放。 | [Spring 启动配置](src/week4/nativeflow/NativeApplication.java) · [调用方](../native_client.py) |
| 验证 | 核对两个节点的顺序、每题诊断、独立调用号、修订分支与原 Linux 判分，并用第十一题验收转人工分支。 | [十题回执](../evidence/native-batch.json) · [保留题输入与返回](../evidence/native-holdout.json) · [引擎方法执行日志](../evidence/native-engine.log) |

以 `abc327_e` 为例，样例 1 预期输出 `256.735020470879931`，基线输出 `256.73502047088016`。两者精确比较失败但符合题面容差。此次浏览器运行的调用号是 `f266ee44-c18b-468e-bec5-275edcce8c70`。诊断节点返回 `numeric_comparator`，分流节点返回 `eligible`。修订候选的 Linux 回执仍为失败，因此外层流程最后转人工。可以用保存的请求体重新调用，核对诊断与分流，并得到新的调用号。[同一真实请求的输入](../evidence/native-example-request.json)

## 复现

运行需要 Python 3.10+、可用的 JDK 8（含 `java`、`javac` 与 `jar`）和原 RSI-Flow Spring 后端构建出的 `core-starter-1.0.0-executable.jar`。本次从该包加载原版流程引擎 0.4.14 和原版 HTTP Controller/Service，在本机独立端口启动 Spring 实例。所用后端包的 SHA-256 为 `75c4c9c4b766a0276f0fe49f2b7c5f381fe5d367ea10f375a05d7cbc372df731`。下列命令从仓库的 `week4-2` 目录运行。

```sh
python native/launch.py --backend PATH_TO_CORE_STARTER_EXECUTABLE_JAR --build /path/to/build
curl http://127.0.0.1:39914/week4/registration
curl -H "Content-Type: application/json" --data-binary @evidence/native-example-request.json http://127.0.0.1:39914/api/engine/flow
```

另开终端启动原生模式的批次执行器。三个数据文件的还原步骤见主报告。将提交的 `platform/app/context-repair` 放入前端项目的 `app` 目录后，启动前端开发服务，访问 `/context-repair/batch?native=1` 并点击“运行 10 题”。

```sh
python batch_service.py --port 39915 --native-engine http://127.0.0.1:39914 --dataset restored/pilot.json --dataset restored/heldout.json --dataset restored/recovery-source.json --output evidence/native-batch.json
python native/verify.py --engine http://127.0.0.1:39914
```

只核查归档回执可运行 `python native/verify.py`。新增的原生节点负责诊断和分流，公开程序复测由 Python 执行，正式成绩沿用与相同候选哈希绑定的 Linux 回执。整体成绩为 10 道全部取得正式终态，8 道正式修复，2 道转人工。
