"""Post-hoc Sudoku experiment: within-stack column permutations preserve validity."""
from argparse import ArgumentParser
import ast
from itertools import combinations, permutations, product
import json
from pathlib import Path
from random import Random
from run import ROOT, digest, neighbors, run, load_datasets
from probes import generate, expected


def main():
    p = ArgumentParser()
    p.add_argument("--dataset", required=True, type=Path)
    p.add_argument("--out", required=True, type=Path)
    args = p.parse_args()
    plan = json.loads((ROOT/"protocol.json").read_bytes())
    task = "abc327_c"
    original = (ROOT/"controls"/(task+".py")).read_text(encoding="utf8")
    site = "215:offset-1"
    candidate = dict(neighbors(original))[site]
    good, bad = [compile(v,task,"exec") for v in (original,candidate)]
    base = generate(task,1,Random(71200))
    grid = [line.split() for line in base.splitlines()]
    swaps = []
    for stack in range(3):
        for a,b in combinations(range(3*stack,3*stack+3),2):
            order = list(range(9))
            order[a],order[b] = order[b],order[a]
            swaps.append(((a+1,b+1),order))
    counts = {}
    first = None
    for label, orders in [("single_swap",swaps),("all_permutations", [
            (None, sum((list(group) for group in blocks), []))
            for blocks in product(*(permutations(range(3*i,3*i+3)) for i in range(3)))])]:
        correct = hits = 0
        for swap,order in orders:
            stdin = "\n".join(" ".join(row[i] for i in order) for row in grid)+"\n"
            assert expected(task, stdin) == "Yes"
            correct += run(good,stdin) == ["Yes"]
            got = run(bad,stdin)
            if got != ["Yes"]:
                hits += 1
                if first is None:
                    first = {"swap_1based":swap, "input":stdin, "expected":"Yes", "observed":got}
        counts[label] = {"n":len(orders), "control_pass":correct, "detected":hits}
    hidden = load_datasets([args.dataset],[dict(id=task,frozen=True,data_sha256=plan["data_sha256"])])[task]
    public = json.loads(next(row for row in json.loads(args.dataset.read_bytes()) if row["question_id"]==task)["public_test_cases"])
    selection = public + [{"input":first["input"],"output":first["expected"]}]
    # A within-stack column swap points to the column subscript of a 2D lookup.
    # Prioritize existing edits in that region without inserting a desired constant.
    tree = ast.parse(candidate)
    column_nodes = {id(node) for sub in ast.walk(tree) if isinstance(sub,ast.Subscript)
                    and isinstance(sub.value,ast.Subscript) for node in ast.walk(sub.slice)}
    positions = {i for i,node in enumerate(ast.walk(tree)) if id(node) in column_nodes}
    hypotheses = list(neighbors(candidate))
    guided = sorted(hypotheses,key=lambda h:int(h[0].split(":")[0]) not in positions)
    repair = {}
    for order, pool in [("original_order",hypotheses),("column_index_first",guided)]:
        item = {"attempted":0, "outcome":"no_candidate"}
        repair[order] = item
        for j,(how,patch) in enumerate(pool[:16],start=1):
            prog=compile(patch,task,"exec")
            item["attempted"]=j
            if all(run(prog,case["input"])==case["output"].strip().splitlines() for case in selection):
                passed=sum(run(prog,case["input"])==case["output"].strip().splitlines() for case in hidden)
                item.update(outcome="pass_hidden" if passed==len(hidden) else "fail_hidden",
                            patch=how,private_pass=passed,private_total=len(hidden),
                            patch_sha256=digest(patch.encode()))
                break
    evidence={"phase":"post_hoc_not_in_primary_comparison","program_sha256":digest(candidate.encode()),
              "site":site,"base":base, "base_actual":run(bad,base),"counts":counts,"first_example":first,
              "bounded_repair":repair}
    args.out.write_text(json.dumps(evidence,ensure_ascii=False,indent=2),encoding="utf8")
    print(counts,repair,first["swap_1based"])


if __name__=="__main__":
    main()

