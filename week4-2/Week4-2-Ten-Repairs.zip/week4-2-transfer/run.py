"""Paired execution pilot. Data file is optional only for inspecting the archived report."""
import argparse
import ast
from contextlib import redirect_stdout
from copy import deepcopy
from datetime import datetime, timezone
from hashlib import sha256
import io
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent / "week4-2"))
from replay import load_datasets
from probes import expected, schedules


def digest(b):
    return sha256(b).hexdigest()


def alternatives(node):
    if isinstance(node, (ast.For, ast.comprehension)):
        base = node.iter
        if (isinstance(base, ast.Subscript) and isinstance(base.slice, ast.Slice)
                and isinstance(base.value, ast.Call) and ast.unparse(base.value.func) == "list"):
            yield "restore_iter", "iter", base.value.args[0]
        for name, suffix in [("omit_first", "[1:]"), ("omit_last", "[:-1]")]:
            yield name, "iter", ast.parse("list(" + ast.unparse(base) + ")" + suffix, mode="eval").body
    if isinstance(node, ast.Compare) and len(node.ops) == 1:
        pairs = {ast.GtE: ast.Gt, ast.Gt: ast.GtE, ast.LtE: ast.Lt, ast.Lt: ast.LtE,
                 ast.Eq: ast.NotEq, ast.NotEq: ast.Eq}
        new = pairs.get(type(node.ops[0]))
        if new:
            yield "comparison", "ops", [new()]
    if isinstance(node, ast.Constant) and type(node.value) is int:
        for step in (-1, 1):
            if node.value + step >= 0:
                yield "offset" + str(step), "value", node.value + step
    if isinstance(node, ast.Attribute) and node.attr in ("bisect_left", "bisect_right"):
        yield "bisect", "attr", "bisect_right" if node.attr == "bisect_left" else "bisect_left"


def neighbors(code):
    tree = ast.parse(code)
    seen = {ast.unparse(tree)}
    for index, node in enumerate(ast.walk(tree)):
        for change, attr, value in alternatives(node):
            other = deepcopy(tree)
            newnode = list(ast.walk(other))[index]
            setattr(newnode, attr, deepcopy(value))
            text = ast.unparse(ast.fix_missing_locations(other))
            if text not in seen:
                seen.add(text)
                yield f"{index}:{change}", text


def run(program, stdin):
    old = sys.stdin
    stdout = io.StringIO()
    try:
        sys.stdin = io.StringIO(stdin)
        with redirect_stdout(stdout):
            exec(program, {"__name__": "__main__"})
        return stdout.getvalue().strip().splitlines()
    except (ArithmeticError, ValueError, IndexError, TypeError, EOFError) as exc:
        return ["<" + type(exc).__name__ + ">"]
    finally:
        sys.stdin = old


def evaluate(task, control, public, hidden, plan):
    named = {"A": [], "B": [], "C": [], "D": []}
    generated = {}
    expected_by_input = {s["input"]: s["output"].strip().splitlines() for s in public}
    for stdin, outputs in expected_by_input.items():
        assert expected(task, stdin).splitlines() == outputs
    for seed in plan["seeds"]:
        for arm, inputs in schedules(task, seed).items():
            named[arm].append(inputs)
            for stdin in inputs:
                if stdin not in generated:
                    generated[stdin] = expected(task, stdin).splitlines()
    tests = dict(expected_by_input, **generated)
    hidden_cases = [(s["input"], s["output"].strip().splitlines()) for s in hidden]
    compiled = compile(control, task, "exec")
    assert all(run(compiled, s) == correct for s, correct in tests.items())
    assert all(run(compiled, s) == correct for s, correct in hidden_cases)
    rec = {"task":task, "original_sha256":digest(control.encode()), "private_groups":len(hidden),
           "public_groups":len(public), "generated_distinct":len(generated), "control_false_alarms":0,
           "variants":[], "first_example":None}
    public_inputs = list(expected_by_input)
    for site, variant in neighbors(control):
        compiled = compile(variant, task, "exec")
        row = {"site":site, "code_sha256":digest(variant.encode())}
        rec["variants"].append(row)
        if any(run(compiled, s) != expected_by_input[s] for s in public_inputs):
            row["label"] = "caught_public"
            continue
        # Which programs belong to the target stratum is scored separately.
        # Neither schedules nor neighborhood selection consume hidden outputs.
        if all(run(compiled, s) == correct for s, correct in hidden_cases):
            row["label"] = "passes_archived_hidden"
            continue
        row["label"] = "hidden_failure_after_public_pass"
        actual = {s:run(compiled,s) for s in generated}
        row["arms"] = {}
        for arm, repeats in named.items():
            hits = [any(actual[s] != generated[s] for s in inp) for inp in repeats]
            armrec = {"detect":hits, "repair":"not_triggered", "hypotheses":0}
            row["arms"][arm] = armrec
            if hits[0]:
                inputs = list(dict.fromkeys(public_inputs + repeats[0]))
                armrec["repair"] = "no_candidate"
                for j, (how, patch) in enumerate(neighbors(variant), start=1):
                    if j > 16:
                        break
                    armrec["hypotheses"] = j
                    prog = compile(patch, task, "exec")
                    if all(run(prog, s) == tests[s] for s in inputs):
                        armrec["patch"] = how
                        armrec["selected_sha256"] = digest(patch.encode())
                        armrec["repair"] = ("pass_hidden" if all(run(prog,s) == correct for s,correct in hidden_cases)
                                             else "fail_hidden")
                        break
            if arm == "C" and hits[0] and rec["first_example"] is None:
                s = next(s for s in repeats[0] if actual[s] != generated[s])
                rec["first_example"] = {"site":site,"input":s,"expected":generated[s],"actual":actual[s]}
    return rec


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--dataset", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    args = p.parse_args()
    plan_raw = (ROOT/"protocol.json").read_bytes()
    plan = json.loads(plan_raw)
    rows = json.loads(args.dataset.read_bytes())
    hidden = load_datasets([args.dataset], [dict(id=t, frozen=True, data_sha256=plan["data_sha256"])
                                                  for t in plan["questions"]])
    report = {"started_utc":datetime.now(timezone.utc).isoformat(), "protocol_sha256":digest(plan_raw),
              "script_hashes":{f:digest((ROOT/f).read_bytes()) for f in ("probes.py","run.py")},
              "dataset_sha256":plan["data_sha256"], "tasks":[]}
    for task in plan["questions"]:
        public = json.loads(next(r for r in rows if r["question_id"]==task)["public_test_cases"])
        code = (ROOT/"controls"/(task+".py")).read_bytes().decode("utf8")
        rec = evaluate(task,code,public,hidden[task],plan)
        report["tasks"].append(rec)
        print(task, len(rec["variants"]), sum("arms" in v for v in rec["variants"]),flush=True)
    report["completed_utc"] = datetime.now(timezone.utc).isoformat()
    args.out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf8")


if __name__ == "__main__":
    main()

