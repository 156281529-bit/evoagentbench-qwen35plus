"""Five bounded adapters; the same four selection policies serve every task."""
from difflib import SequenceMatcher
from random import Random


def seq(values):
    return " ".join(map(str, values))


def generate(task, family, rng):
    if task == "abc322_c":
        n = rng.randrange(2, 25)
        days = [i for i in range(1, n) if rng.randrange(2)] + [n]
        if family == 1:
            n, days = 1, [1]
        elif family == 2:
            days = [n-1, n]
        elif family == 3:
            days = [n]
        return f"{n} {len(days)}\n{seq(days)}\n"
    if task == "abc324_a":
        n, v = rng.randint(2, 20), rng.randint(1, 99)
        a = [rng.randint(1, 100) for _ in range(n)]
        if family:
            a = [v] * n
        if family == 2:
            a[0] += 1
        if family == 3:
            a[-1] += 1
        return f"{n}\n{seq(a)}\n"
    if task == "abc327_c":
        digits = list(range(1, 10))
        rng.shuffle(digits)
        grid = [[digits[(r*3+r//3+c) % 9] for c in range(9)] for r in range(9)]
        if family == 0 and rng.randrange(2):
            grid = [[rng.randint(1, 9) for _ in range(9)] for _ in range(9)]
        if family == 2:
            grid[0], grid[3] = grid[3], grid[0]
        if family == 3:
            grid[-1][-1] = grid[-1][-2]
        return "\n".join(map(seq, grid)) + "\n"
    if task == "abc328_b":
        n = rng.randint(1, 35)
        a = [rng.randint(1, 100) for _ in range(n)]
        if family == 1:
            n, a = 1, [1]
        elif family == 2:
            n, a = 11, [1]*10 + [11]
        elif family == 3:
            n, a = 100, [100]*100
        return f"{n}\n{seq(a)}\n"
    if task == "abc330_a":
        n, threshold = rng.randint(2, 20), rng.randint(2, 999)
        a = [rng.randint(0, 1000) for _ in range(n)]
        if family:
            a = [threshold] * n
        if family == 2:
            a[0] = threshold-1
        if family == 3:
            a = [0]*(n-1) + [threshold]
        return f"{n} {threshold}\n{seq(a)}\n"
    raise KeyError(task)


def expected(task, stdin):
    a = list(map(int, stdin.split()))
    if task == "abc322_c":
        n, m, *days = a
        return "\n".join(str(min(d-i for d in days if d >= i)) for i in range(1, n+1))
    if task == "abc324_a":
        return "Yes" if min(a[1:]) == max(a[1:]) else "No"
    if task == "abc327_c":
        def box(i):
            return i//27*3 + i%9//3
        for group in (lambda i: i//9, lambda i: i%9, box):
            if len({(group(i), v) for i, v in enumerate(a)}) != 81:
                return "No"
        return "Yes"
    if task == "abc328_b":
        count = 0
        for digit in range(1, 10):
            for month in (digit, 11*digit):
                if month <= a[0]:
                    count += sum(day <= a[month] for day in (digit, 11*digit))
        return str(count)
    if task == "abc330_a":
        return str(a[0] - sum(score < a[1] for score in a[2:]))
    raise KeyError(task)


def schedules(task, seed):
    rng = Random(str(seed) + task)
    pool = [generate(task, 0, rng) for _ in range(16)]
    pool.extend(generate(task, family, rng) for family in range(1, 4))
    uniform = rng.sample(range(19), 4)
    chosen = [uniform[0]]
    tokens = [s.split() for s in pool]
    while len(chosen) < 4:
        rest = [i for i in range(19) if i not in chosen]
        chosen.append(max(rest, key=lambda i: min(
            1 - SequenceMatcher(None, tokens[i], tokens[j], autojunk=False).ratio() for j in chosen)))
    return {name: [pool[i] for i in indexes] for name, indexes in {
        "A": [], "B": uniform, "D": chosen, "C": [rng.randrange(16), 16, 17, 18]}.items()}

