def solve():
    # Read the 9x9 grid
    grid = []
    for _ in range(9):
        row = list(map(int, input().split()))
        grid.append(row)
    
    # Check condition 1: Each row contains 1-9 exactly once
    for i in range(9):
        if sorted(grid[i]) != list(range(1, 10)):
            print("No")
            return
    
    # Check condition 2: Each column contains 1-9 exactly once
    for j in range(9):
        col = [grid[i][j] for i in range(9)]
        if sorted(col) != list(range(1, 10)):
            print("No")
            return
    
    # Check condition 3: Each 3x3 subgrid contains 1-9 exactly once
    for box_row in range(3):
        for box_col in range(3):
            subgrid = []
            for i in range(3):
                for j in range(3):
                    subgrid.append(grid[box_row * 3 + i][box_col * 3 + j])
            if sorted(subgrid) != list(range(1, 10)):
                print("No")
                return
    
    print("Yes")

if __name__ == "__main__":
    solve()