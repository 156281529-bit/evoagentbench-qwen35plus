# Read N and L from the first line
line1 = input().split()
N = int(line1[0])
L = int(line1[1])

# Read the scores from the second line
scores = list(map(int, input().split()))

# Count how many people passed (scored at least L points)
passed_count = sum(1 for score in scores if score >= L)

# Print the result
print(passed_count)