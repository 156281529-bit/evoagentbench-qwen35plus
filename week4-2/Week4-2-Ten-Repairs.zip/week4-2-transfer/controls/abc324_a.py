# Read N
n = int(input())
# Read the list of A values
a = list(map(int, input().split()))

# Check if all values are equal
if all(x == a[0] for x in a):
    print("Yes")
else:
    print("No")