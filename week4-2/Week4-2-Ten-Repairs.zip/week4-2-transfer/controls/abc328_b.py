def is_repdigit(month, day):
    """Check if all digits in month and day are the same."""
    s = str(month) + str(day)
    return all(c == s[0] for c in s)

def main():
    N = int(input())
    D = list(map(int, input().split()))
    
    count = 0
    for i in range(1, N + 1):
        for j in range(1, D[i-1] + 1):
            if is_repdigit(i, j):
                count += 1
    
    print(count)

if __name__ == "__main__":
    main()