import bisect

# Read input
N, M = map(int, input().split())
A = list(map(int, input().split()))

# For each day i from 1 to N, find the first fireworks day >= i
# Using binary search (bisect_left) to find the index
for i in range(1, N + 1):
    idx = bisect.bisect_left(A, i)
    # A[idx] is the first fireworks day >= i
    print(A[idx] - i)