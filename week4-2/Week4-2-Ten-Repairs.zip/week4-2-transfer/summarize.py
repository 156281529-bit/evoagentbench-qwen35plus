"""Aggregate paired runs. Seeds repeat the same programs; they are not new tasks."""
from collections import Counter
import json
from pathlib import Path
from run import ROOT, digest


def aggregate(data, follow):
    variants = [v for t in data["tasks"] for v in t["variants"]]
    eligible = [v for v in variants if "arms" in v]
    controls = {t["task"]: t["control_false_alarms"] for t in data["tasks"]}
    stats = {}
    for arm in ("A","B","D","C"):
        runs = [v["arms"][arm] for v in eligible]
        stats[arm] = {"hits":sum(sum(r["detect"]) for r in runs),
                      "opportunities":sum(len(r["detect"]) for r in runs),
                      "first_seed_caught":sum(r["detect"][0] for r in runs),
                      "first_seed_hidden_pass":sum(r["repair"]=="pass_hidden" for r in runs)}
    matched = Counter()
    for v in eligible:
        for b,c in zip(v["arms"]["B"]["detect"],v["arms"]["C"]["detect"]):
            matched["both" if b and c else "only_C" if c else "only_B" if b else "neither"]+=1
    return {"labels":dict(Counter(v["label"] for v in variants)), "total":len(variants),
            "task_eligible":{t["task"]:sum("arms" in v for v in t["variants"]) for t in data["tasks"]},
            "controls":controls,"arms":stats,"paired_B_C":dict(matched),
            "posthoc":follow["counts"], "posthoc_repair":follow["bounded_repair"]}


if __name__=="__main__":
    data = json.loads((ROOT/"results.json").read_bytes())
    assert digest((ROOT/"protocol.json").read_bytes()) == data["protocol_sha256"]
    for f, sha in data["script_hashes"].items():
        assert digest((ROOT/f).read_bytes()) == sha
    for t in data["tasks"]:
        assert digest((ROOT/"controls"/(t["task"]+".py")).read_bytes()) == t["original_sha256"]
    follow = json.loads((ROOT/"followup-results.json").read_bytes())
    print(json.dumps(aggregate(data,follow),ensure_ascii=False,indent=2))

