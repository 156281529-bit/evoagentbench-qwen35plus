"""Validate Linux verdicts, identify unique repaired IDs, and link them to the actual routed candidates."""
import json
from hashlib import sha256
from pathlib import Path

ROOT=Path(__file__).resolve().parent
def read(p): return json.loads(p.read_bytes())
def audit():
    old=read(ROOT.parent/"week4-2/evidence/official-after.json")
    pairs=read(ROOT/"official-pairs.json")
    rows=read(ROOT/"manifest.json")
    routed={r["id"]:r for r in read(ROOT/"local-pairs.json")["tasks"]}
    assert pairs["complete"] and pairs["livecodebench_commit"]==old["livecodebench_commit"]
    assert pairs["image_id"]==old["image_id"]
    assert len(rows)==2 and len(pairs["rows"])==4 and len({r["id"] for r in rows})==2
    successful={r["id"] for r in old["rows"] if r.get("reward")==1 and r["passed"]==r["groups_available"]}
    assert len(successful)==8 and not ({r["id"] for r in rows} & {r["id"] for r in old["rows"]})
    for r in rows:
        task=r["id"]
        local=routed[task]
        assert local["route"]["task"]==task and local["route"]["outcome"]=="eligible"
        assert local["route"]["nodes"]==["WEEK4_DIAGNOSE","WEEK4_ROUTE"]
        assert not local["before"]["probe"]["exact"] and local["after"]["probe"]["exact"]
        for side in ("before","after"):
            entry=next(x for x in pairs["rows"] if x["id"]==task and x["side"]==side)
            fingerprint=sha256((ROOT/side/(task+".py")).read_bytes()).hexdigest()
            assert r[side+"_sha256"]==entry["code_sha256"]==local[side]["sha256"]==fingerprint
            assert entry["data_sha256"]==r["data_sha256"] and entry["judge_platform"]=="Linux"
            assert entry["available"]==len(local[side]["private"])+len(r["samples"])
            if side=="before":
                assert entry["reward"]==0 and entry["error_code"]==-2 and entry["total"]==len(entry["results"])
            else:
                assert entry["reward"]==1 and entry["passed"]==entry["total"]==entry["available"]
                assert entry["results"]==[1]*entry["available"]
        successful.add(task)
    assert len(successful)==10 and set(pairs["verified_repairs"])=={r["id"] for r in rows}
    return sorted(successful)

if __name__=="__main__":
    print("10 distinct officially verified repairs:",", ".join(audit()))

