import argparse
import io
import json
import sys
from contextlib import redirect_stdout
from itertools import combinations, permutations, product
from pathlib import Path

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/"week4-2"))
from replay import load_datasets, sha, trial
from native_client import dispatch, registration

PROBES={"abc335_c":{"input":"3 2\n1 U\n2 3\n","output":"2 0"},
        "abc320_c":{"input":"1\n9\n9\n9\n","output":"2"}}

def cases(task):
    if task=="abc320_c":
        for period in (1,2,3):
            strings=["".join(bits) for bits in product("01",repeat=period)]
            for reels in product(strings,repeat=3):
                finish=3*period
                for times in combinations(range(3*period),3):
                    for assignment in permutations(times):
                        if len({reel[t%period] for reel,t in zip(reels,assignment)})==1:
                            finish=min(finish,times[-1])
                            break
                yield str(period)+"\n"+"\n".join(reels)+"\n", str(finish if finish<3*period else -1)
        return
    steps={"R":(1,0),"L":(-1,0),"U":(0,1),"D":(0,-1)}
    for n in (3,5):
        for length in range(5):
            for moves in product(steps,repeat=length):
                body=[(p,0) for p in range(1,n+1)]
                queries=[]
                answers=[]
                for move in (None,*moves):
                    if move:
                        dx,dy=steps[move]
                        x,y=body[0]
                        body=[(x+dx,y+dy)]+body[:-1]
                        queries.append("1 "+move)
                    for p,(x,y) in enumerate(body,1):
                        queries.append(f"2 {p}")
                        answers.append(f"{x} {y}")
                yield f"{n} {len(queries)}\n"+"\n".join(queries)+"\n", "\n".join(answers)

def fast(code,text):
    inp=sys.stdin
    out=io.StringIO()
    try:
        sys.stdin=io.StringIO(text)
        with redirect_stdout(out): exec(code,{"__name__":"__main__"})
        return out.getvalue().strip()
    finally: sys.stdin=inp

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--archive",required=True,type=Path)
    p.add_argument("--endpoint")
    p.add_argument("--out",required=True,type=Path)
    a=p.parse_args()
    book=json.loads((ROOT/"manifest.json").read_bytes())
    out={"tasks":[]}
    if a.endpoint: out["native_registration"]=registration(a.endpoint)
    for r in book:
        task=r["id"]
        row={"id":task}
        private=load_datasets([a.archive/r["dataset"]],[r])[task]
        grid=list(cases(task))
        for side in ("before","after"):
            path=ROOT/side/(task+".py")
            raw=path.read_bytes()
            assert sha(raw)==r[side+"_sha256"]
            compiled=compile(raw,str(path),"exec")
            entry={"sha256":sha(raw),"public":[trial(task,path,c,True) for c in r["samples"]],
                   "probe":trial(task,path,PROBES[task],True)}
            if side=="before" and a.endpoint:
                row["route"]=dispatch(a.endpoint,task,entry["public"],[entry["probe"]])
                if row["route"]["outcome"]!="eligible": raise ValueError("Repair not routed")
            entry["private"]=[trial(task,path,c,False) for c in private]
            entry["generated"]={"passed":sum(fast(compiled,s)==e for s,e in grid),"total":len(grid)}
            row[side]=entry
            print(task,side,entry["generated"],"public",sum(c["exact"] for c in entry["public"]),len(entry["public"]),
                  "private",sum(c["exact"] for c in entry["private"]),len(private),flush=True)
        out["tasks"].append(row)
    a.out.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding="utf8")

if __name__=="__main__": main()

