"""Rejudge archived complete baseline snapshots and revised solutions on identical groups."""
import argparse
import json
import shutil
import subprocess
import sys
import tempfile
import uuid
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
V2 = ROOT.parent / "week4-2"
sys.path.insert(0, str(V2))
from replay import load_datasets, sha

def cli_program(name, fallback):
    return shutil.which(name) or fallback

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--archive",type=Path,required=True)
    args=p.parse_args()
    manifest=json.loads((ROOT/"manifest.json").read_bytes())
    original=json.loads((V2/"evidence/official-after.json").read_bytes())
    lcb=(args.archive/"evoagentbench-expansion/LiveCodeBench").resolve()
    git=cli_program("git","C:/Program Files/Git/cmd/git.exe")
    docker=cli_program("docker","C:/Program Files/Docker/Docker/resources/bin/docker.exe")
    commit=subprocess.check_output([git,"-c",f"safe.directory={lcb.as_posix()}","-C",str(lcb),"rev-parse","HEAD"],text=True).strip()
    if commit!=original["livecodebench_commit"]: raise RuntimeError("Different judge revision")
    image=original["image_id"]
    if subprocess.check_output([docker,"image","inspect","--format","{{.Id}}",image],text=True).strip()!=image:
        raise RuntimeError("Different judge image")
    records=[]
    report={"engine":original["engine"],"image_id":image,"livecodebench_commit":commit,
            "started":datetime.now(timezone.utc).isoformat(),"rows":records,"complete":False}
    def save():
        tmp=ROOT/"official-pairs.tmp"
        tmp.write_text(json.dumps(report,indent=2),encoding="utf8")
        tmp.replace(ROOT/"official-pairs.json")
    for r in manifest:
        task=r["id"]
        private=load_datasets([args.archive/r["dataset"]],[r])[task]
        cases=r["samples"]+private
        for side in ("before","after"):
            code=(ROOT/side/(task+".py")).read_bytes()
            if sha(code)!=r[side+"_sha256"]: raise RuntimeError("Source changed")
            name="week4-extra-"+uuid.uuid4().hex[:12]
            with tempfile.TemporaryDirectory() as directory:
                temp=Path(directory)
                (temp/"candidate.py").write_bytes(code)
                specimen={"inputs":[c["input"] for c in cases],"outputs":[c["output"] for c in cases],"fn_name":None}
                (temp/"sample.json").write_text(json.dumps({"input_output":json.dumps(specimen)}),encoding="utf8")
                command=[docker,"run","--rm","--name",name,"--network","none","--memory","2g","--cpus","2",
                         "--pids-limit","256","--mount",f"type=bind,source={lcb},target=/lcb,readonly",
                         "--mount",f"type=bind,source={temp},target=/trial","--mount",
                         f"type=bind,source={V2/'judge.py'},target=/app/verify.py,readonly",image,"python","/app/verify.py"]
                try:
                    subprocess.run(command,check=True,timeout=240)
                except subprocess.TimeoutExpired:
                    subprocess.run([docker,"rm","-f",name],capture_output=True)
                    raise
                result=json.loads((temp/"judge-result.json").read_bytes())
            if result.get("error") or result.get("judge_platform")!="Linux" or not result.get("total"):
                raise RuntimeError(f"{task}: no valid Linux verdict")
            record={k:result[k] for k in ("results","passed","total","reward","judge_platform","judge_python")}
            record.update(id=task,side=side,code_sha256=sha(code),data_sha256=r["data_sha256"],available=len(cases),
                          error_code=(result.get("metadata") or {}).get("error_code"))
            records.append(record)
            print(task,side,record["reward"],f'{record["passed"]}/{record["total"]}',flush=True)
            save()
    report["complete"]=True
    report["verified_repairs"]=[r["id"] for r in manifest
        if any(x["id"]==r["id"] and x["side"]=="before" and x["reward"]==0 and x["error_code"]==-2 for x in records)
        and any(x["id"]==r["id"] and x["side"]=="after" and x["reward"]==1 and x["passed"]==x["available"] for x in records)]
    save()
    print("Verified repairs:",report["verified_repairs"],flush=True)


if __name__=="__main__":
    main()

