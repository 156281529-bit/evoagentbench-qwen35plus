from bisect import bisect_right
from itertools import permutations


def solve():
    period = int(input())
    reels = [input().strip() for _ in range(3)]
    best = 3 * period
    for digit in set(reels[0]).intersection(*reels[1:]):
        positions = [[i for i, char in enumerate(reel) if char == digit] for reel in reels]
        for order in permutations(positions):
            time = -1
            for matching in order:
                cycle, offset = divmod(time, period)
                j = bisect_right(matching, offset)
                if j == len(matching):
                    cycle += 1
                    j = 0
                time = cycle * period + matching[j]
            best = min(best, time)
    print(best if best < 3 * period else -1)


if __name__ == "__main__":
    solve()

