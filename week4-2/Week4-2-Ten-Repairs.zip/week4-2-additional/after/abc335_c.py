import sys


def solve():
    read = sys.stdin.readline
    _, queries = map(int, read().split())
    head = [(1, 0)]
    steps = {"R": (1, 0), "L": (-1, 0), "U": (0, 1), "D": (0, -1)}
    for _ in range(queries):
        kind, value = read().split()
        if kind == "1":
            x, y = head[-1]
            dx, dy = steps[value]
            head.append((x + dx, y + dy))
        else:
            # Before move zero the dragon lies at (1,0), (2,0), ...
            time = len(head) - int(value)
            if time >= 0:
                print(*head[time])
            else:
                print(1 - time, 0)


if __name__ == "__main__":
    solve()

