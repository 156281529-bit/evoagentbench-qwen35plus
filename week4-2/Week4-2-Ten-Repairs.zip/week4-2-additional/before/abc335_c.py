import sys

def solve():
    input = sys.stdin.readline
    N, Q = map(int, input().split())
    
    # history[i] = head position after i moves
    # history[0] = initial position (1, 0)
    history = [(1, 0)]
    
    for _ in range(Q):
        query = input().split()
        if query[0] == '1':
            C = query[1]
            x, y = history[-1]
            if C == 'R':
                x += 1
            elif C == 'L':
                x -= 1
            elif C == 'U':
                y += 1
            elif C == 'D':
                y -= 1
            history.append((x, y))
        else:
            p = int(query[1])
            k = len(history) - 1  # number of moves made
            if k >= p - 1:
                x, y = history[k - (p - 1)]
            else:
                x, y = p, 0
            print(x, y)

if __name__ == "__main__":
    solve()
