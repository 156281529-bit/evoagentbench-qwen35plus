# Read input
M = int(input())
S1 = input()
S2 = input()
S3 = input()

ans = float('inf')

# Try each digit 0-9
for d in '0123456789':
    # Find positions where digit d appears in each reel
    pos1 = [i for i in range(M) if S1[i] == d]
    pos2 = [i for i in range(M) if S2[i] == d]
    pos3 = [i for i in range(M) if S3[i] == d]
    
    # If digit d doesn't appear in all three reels, skip it
    if not pos1 or not pos2 or not pos3:
        continue
    
    # For each reel, we can stop at the minimum position where d appears
    p1 = min(pos1)
    p2 = min(pos2)
    p3 = min(pos3)
    
    # The time when all reels are stopped is the maximum of the three times
    time_needed = max(p1, p2, p3)
    
    # Update minimum answer
    ans = min(ans, time_needed)

if ans == float('inf'):
    print(-1)
else:
    print(ans)
